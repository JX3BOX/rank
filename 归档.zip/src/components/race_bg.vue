<template>
    <div class="m-rank-bg">
        <!-- 背景效果 -->
    </div>
</template>

<script>
export default {
    name: "raceBg",
    props: [],
    data: function() {
        return {};
    },
    computed: {},
    methods: {},
    mounted: function() {},
    components: {},
};
</script>
