<template>
    <div class="container">
        <!-- top_banner -->
        <div class="m-top">
            <img class="m-top_backdrop" src="@/assets/img/kv/KV.png" />
            <div class="m-top_ghost_btn"></div>
        </div>
        <!-- m-notice -->
        <div class="m-notice">
            <!-- <img class="m-notice_backdrop" src="@/assets/img/kv/BG.png" /> -->
            <div class="m-notice-box">
                <div class="m-notice-tabs">
                    <div :class="['m-notice-tabs_item', active == 1 && 'is_active']" @click="active = 1">赛事介绍</div>
                    <div :class="['m-notice-tabs_item', active == 2 && 'is_active']" @click="active = 2">赛事奖励</div>
                </div>

                <!-- 内容 -->
                <div class="m-notice-content">
                    <!-- 报名按钮 -->
                    <div class="m-notice-content_enroll_btn">我已了解，前往报名</div>
                </div>
            </div>
        </div>
        <!-- 01 -->
        <div class="m-one">
            <img class="m-one-tangmen" src="@/assets/img/kv/tangmen.png" />
            <div class="m-one-title_box">
                <img class="m-one-title" src="@/assets/img/kv/01_title.png" alt="" />
                <div class="m-one-btn_box">
                    <global-btn> 团队报名 </global-btn>
                    <global-btn> 绑定角色 </global-btn>
                </div>
                <div class="m-one_tips">*报名仅限团长操作，各位团长请先给团队进行报名</div>
                <div class="m-one_warning">
                    <img class="m-warning_icon" src="@/assets/img/kv/ic_round-warning.png" />
                    <span>如果你曾经报名过赛事，且没有角色变更，则<br />不需要重新绑定角色</span>
                </div>
            </div>
        </div>
        <!-- 背景图 -->
        <img class="m-backdrop" src="@/assets/img/kv/backdrop_one.png" />

        <div class="m-two">
            <img class="m-two-cangjian" src="@/assets/img/kv/cangjian.png" />
            <div class="m-two-title_box">
                <img class="m-two-title" src="@/assets/img/kv/02_title.png" />
                <div class="m-two-btn_box">
                    <global-btn> 报名参赛 </global-btn>
                    <global-btn> 创建团队 </global-btn>
                </div>
                <div class="m-two-btn_box_tips">*如果没有团队，则先创建团队后再报名</div>
            </div>
        </div>
    </div>
</template>

<script>
import global_btn from "@/components/kv/global_btn.vue";
export default {
    components: {
        "global-btn": global_btn,
    },
    props: [],
    data: () => ({
        active: 1, //tabs状态
    }),
    computed: {
        id: function () {
            return this.$store.state.id;
        },
        desc: function () {
            return this.$store.state.race.desc;
        },
    },
    methods: {},
    filters: {},
    mounted: function () {},
    created: function () {},
};
</script>

<style lang="less" scoped>
.container {
    width: 3840px;
}

.m-backdrop {
    height: 300px;
}
.m-two {
    height: 900px;
    background-image: url("../../../assets/img/kv/02.png");
    margin-top: -4px;
    position: relative;
    .m-two-title_box {
        position: absolute;
        right: 1180px;
        top: 174px;
        z-index: 9;
        display: flex;
        flex-direction: column;
        .m-two-title {
            margin-bottom: 30px;
        }
        .m-two-btn_box {
            display: flex;
            gap: 20px;
            align-items: center;
        }
        .m-two-btn_box_tips {
            font-family: "Microsoft YaHei";
            margin-top: 10px;
            font-style: normal;
            text-align: right;
            width: 360px;
            font-weight: 700;
            font-size: 16px;
            color: #ffffff;
        }
    }

    .m-two-cangjian {
        position: absolute;
        left: -20px;
        top: -1277px;
        z-index: 1;
        width: 3051px;
        height: 3051px;
        object-fit: contain;
    }
}
.m-one {
    height: 900px;
    background-image: url("../../../assets/img/kv/01.png");
    position: relative;
    .m-one-title_box {
        position: absolute;
        left: 1180px;
        top: 136px;
        z-index: 9;
        .m-one_warning {
            display: flex;
            // align-items: center;
            font-family: "Microsoft YaHei";
            font-weight: 700;
            font-size: 14px;
            line-height: 18px;
            color: #fff;
            .m-warning_icon {
                width: 15px;
                height: 15px;
            }
        }
        .m-one_tips {
            font-family: "Microsoft YaHei";
            font-style: normal;
            font-weight: 700;
            font-size: 16px;
            color: #ffffff;
            margin: 10px 0 30px 0;
        }
        .m-one-title {
            margin-bottom: 30px;
        }
        .m-one-btn_box {
            display: flex;
            align-items: center;
            gap: 20px;
            .m-one-btn_img {
                cursor: pointer;
                width: 165px;
                height: 82px;
            }
        }
    }

    // .img_head {
    //     position: absolute;
    //     right: 0;
    //     top: -795px;
    //     z-index: 1;
    // }
    .m-one-tangmen {
        position: absolute;
        right: 0;
        top: -1396px;
        z-index: 1;
        width: 2962px;
        height: 2962px;
        object-fit: contain;
    }
}
.m-notice {
    height: 1200px;
    // position: relative;
    display: flex;
    justify-content: center;
    padding-top: 112px;
    box-sizing: border-box;
    background-size: cover;
    background-repeat: no-repeat;
    background-image: url("../../../assets/img/kv/BG.png");

    .m-notice_backdrop {
        height: 100%;
        position: absolute;
        left: 0;
        top: 0;
        z-index: -1;
    }
    .m-notice-box {
        background: url("../../../assets/img/kv/box.png");
        width: 1625px;
        height: 976px;
        display: flex;
        position: relative;
        z-index: 9; //低于1, 01的唐门会穿透
        justify-content: center;
        align-items: center;
        flex-direction: column;

        .m-notice-content {
            width: 1100px;
            height: 695px;
            background: #fff;
            margin-top: 32px;
            position: relative;
            .m-notice-content_enroll_btn {
                position: absolute;
                bottom: -45px;
                right: -220px;
                width: 377px;
                height: 90px;
                display: flex;
                align-items: center;
                justify-content: center;
                background: #ba2a2d;
                box-shadow: 0px 0px 10px #ba2a2d;
                font-family: "Microsoft YaHei";
                font-weight: 700;
                font-size: 32px;
                color: #ffffff;
            }
        }
        .m-notice-tabs {
            display: flex;
            align-items: center;
            font-family: "Microsoft YaHei";
            font-weight: 700;
            font-size: 32px;
            color: #010101;
            gap: 70px;
            .m-notice-tabs_item {
                cursor: pointer;
                display: flex;
                align-items: center;
                justify-content: center;
                width: 204px;
                height: 70px;
                background: #e6e6e6;
            }
            .is_active {
                background: #010101;
                color: #fff;
            }
        }
    }
}
.m-top {
    z-index: 2;
    position: relative;
    height: 1200px;
    .m-top_backdrop {
        height: 100%;
    }
    .m-top_ghost_btn {
        background-color: green;
        width: calc(320px + 45px);
        height: 42px;
        position: absolute;
        left: 50%;
        margin-left: -225px;
        bottom: 185px;
        z-index: 1;
    }
}
</style>
