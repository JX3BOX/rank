# Rank
本系列页面不要适配

## 页面
pages | desc
---|---
/ | 资料片导航
event | 活动设置
join | 报名页面
race | 赛事页面

## 赛事路由
race-views | router | desc
---|---|---
~ | / | 根据活动进程显示info或rank
Info | /info | 活动规则、奖项设置
Lucky | /lucky | 晚会回看、中奖结果
Rank | /race | 竞速排行榜榜单
Dps | /dps | 天梯榜、门派天团
Vote | /vote | 人气排行榜
Live | /live | 视频直播
Video | /video | 通关视频
Stat | /stat | 统计分析


## 赛事工作
1. 新增event，确定成就ID，更新event配置+插件配置
2. rank项目首页图新增、前端栏目更新

## 数据更新
1. event后台设置
2. event CDN
3. 本地data/achieve.json
4. team项目achieve.json